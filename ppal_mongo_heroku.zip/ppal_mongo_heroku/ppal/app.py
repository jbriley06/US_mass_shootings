from flask import Flask, render_template
from flask_pymongo import PyMongo
import os

# MONGO_URL = os.environ.get('MONGO_URL')
MONGODB_URI = os.environ.get('MONGODB_URI')
if not MONGODB_URI:
    MONGODB_URI = "mongodb://localhost:27017/test_hurricane_1";

app = Flask(__name__)

app.config['MONGO_URI'] = MONGODB_URI
mongo = PyMongo(app)

@app.before_first_request
def setup():
    # insert some test data
    mongo.db.hurricane.insert_many(
        [
            {
                'name': 'Harvey',
                'cat': 'Category 4'
            },
            {
                'name': 'Irma',
                'cat': 'Category 5'
            }
        ]
    )

@app.route('/')
def index():
    # Query the mongo db for the data
    hurricanes = list(mongo.db.hurricane.find())
    print(hurricanes)
    return render_template('index.html', hurricanes=hurricanes)


if __name__ == "__main__":
    app.run(debug=True)
