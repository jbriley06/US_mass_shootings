FLASK_APP=ppal/app.py flask run
